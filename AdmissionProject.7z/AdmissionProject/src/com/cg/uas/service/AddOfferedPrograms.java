package com.cg.uas.service;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.uas.dao.UserDao;

/**
 * Servlet implementation class AddOfferedPrograms
 */
@WebServlet("/AddOfferedPrograms")
public class AddOfferedPrograms extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String pname=request.getParameter("pname");
		String description=request.getParameter("description");
	
		String eligibility=request.getParameter("eligibility");
		String duration=request.getParameter("duration");
		String certificate=request.getParameter("certificate");
		
		
		UserDao dao=new UserDao();
		int n=dao.addProgramsOffered(pname,description,eligibility,duration,certificate);
		if(n>0)
		{
			out.println("<html><body><p> 1 record added to the database..........</p></body></html>");
			response.sendRedirect("admin.jsp");
			
			//RequestDispatcher rd=request.getRequestDispatcher("login.jsp");
			//rd.forward(request, response);
		}
		
	}

}
