package com.cg.uas.service;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.uas.dao.UserDao;


/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String loginid=request.getParameter("loginid");
		String password=request.getParameter("pass");
		
		
		UserDao dao=new UserDao();
		boolean n=dao.validate(loginid, password);
		if(n)
		{
			
			response.sendRedirect("admin.jsp");
			//RequestDispatcher rd=request.getRequestDispatcher("login.jsp");
			//rd.forward(request, response);
		}
	
	}

}
